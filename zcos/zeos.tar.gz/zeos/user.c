#include <libc.h>

char buff[4];

int pid;

int addASM(int, int);

int zeos_ticks;
int write(int fd, char* buffer,int size);
int gettime();

int __attribute__ ((__section__(".text.main")))
  main(void)
{

	// int numero = addASM(0x42,0x666);
    
  //int* numero = 0;
  //*numero = 0;

  write(1, "write bien\n",11);
    
  char *puntero = buff;

  while(1) {
    // int a = gettime();
    if((write(1,"gettime\n",8)) == -1) perror();
    // itoa(a,puntero);
  	// write(1,puntero,4);
  }
} 
